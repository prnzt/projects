## SMART SCHOLAR APP

  An online Classroom App for students.
  
  Student can 
  1) Attend Online Lectures
  2) View Currciulum
  3) View Individual Performance
  4) Attendance
  5) Quizes

# LOGIN

<img src = "/screenshots/Screenshot_1607235860.png" width="300" height="500"/> 

# MAIN MENU 

<img src = "/screenshots/Screenshot_1607235873.png" width="300" height="500"/> <img src = "/screenshots/Screenshot_1607235879.png" width="300" height="500"/>

# QUIZ/EXAM
<img src = "/screenshots/1.jpg" width="300" height="500"/> <img src = "/screenshots/2.jpg" width="300" height="500"/>
<img src = "/screenshots/3.jpg" width="300" height="500"/> <img src = "/screenshots/4.jpg" width="300" height="500"/>
<img src = "/screenshots/5.jpg" width="300" height="500"/> <img src = "/screenshots/6.jpg" width="300" height="500"/>
<img src = "/screenshots/7.jpg" width="300" height="500"/> <img src = "/screenshots/8.jpg" width="300" height="500"/>



# RESET PASSWORD

<img src = "/smartkaksha clips/Reset Password 1.jpeg" width="300" height="500"/> <img src = "/smartkaksha clips/Reset Password 2.jpeg" width="300" height="500"/> 

# CLASSROOM SESSION

<img src = "/screenshots/Screenshot_1607235900.png" width="300" height="500"/>  <img src = "/smartkaksha clips/Session.jpeg" width="300" height="500"/> 

<img src = "/screenshots/Screenshot_1607235892.png" width="300" height="500"/> <img src = "/smartkaksha clips/Test.jpeg" width="300" height="500"/> 

# SYNCHRONIZE DATA FROM CLOUD

<img src = "/smartkaksha clips/Sync Data.jpeg" width="300" height="500"/> 

# STUDENT PERFORMANCE

<img src = "/smartkaksha clips/Student Info.jpeg" width="300" height="500"/> <img src = "/smartkaksha clips/Student Grades.jpeg" width="300" height="500"/> 


# SESSION CONTENT

<img src = "/screenshots/Screenshot_1607235904.png" width="300" height="500"/> <img src = "/smartkaksha clips/Video.jpeg" width="300" height="500"/> 

<img src = "/smartkaksha clips/Music.jpeg" width="300" height="500"/> <img src = "/smartkaksha clips/Website.jpeg" width="300" height="500"/> 

<img src = "/smartkaksha clips/Pdf.jpeg" width="300" height="500"/> 
