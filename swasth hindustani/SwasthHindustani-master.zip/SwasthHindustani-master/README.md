# SwasthHindustani App

  An online Classroom App for students and teachers
  
  Teacher can
  1) Take Online Lectures
  2) Manage Currciulum
  3) View Student Performance
  4) Attendance
  5) Quizes

# Splash Screen 

<img src = "/Swasth Hindstani clips/Splash Screen 1.png" width="300" height="600"/> <img src = "/Swasth Hindstani clips/Splash Screen 2.png" width="300" height="600"/> 

# Login/Signup

<img src = "/Swasth Hindstani clips/login.png" width="300" height="600"/> <img src = "/Swasth Hindstani clips/Signup.png" width="300" height="600"/> 

# DashBoard

<img src = "/Swasth Hindstani clips/Dashboard.png" width="300" height="600"/> 

# Homepage

<img src = "/Swasth Hindstani clips/Home Screen 1.png" width="300" height="600"/> <img src = "/Swasth Hindstani clips/Home Screen 2.png" width="300" height="600"/> 


# Service Screens

<img src = "/Swasth Hindstani clips/Services page 1.png" width="300" height="600"/> <img src = "/Swasth Hindstani clips/Services page 2.1.png" width="300" height="600"/> 
<img src = "/Swasth Hindstani clips/Services page 2.2.png" width="300" height="600"/> <img src = "/Swasth Hindstani clips/Services page 2.3.png" width="300" height="600"/> 


# Client Profile Screens

<img src = "/Swasth Hindstani clips/Profile 1.png" width="300" height="600"/> <img src = "/Swasth Hindstani clips/Profile 2.png" width="300" height="600"/> 
<img src = "/Swasth Hindstani clips/Profile 3.png" width="300" height="600"/> <img src = "/Swasth Hindstani clips/Profile 4.png" width="300" height="600"/> 
<img src = "/Swasth Hindstani clips/Profile 5.png" width="300" height="600"/> 



