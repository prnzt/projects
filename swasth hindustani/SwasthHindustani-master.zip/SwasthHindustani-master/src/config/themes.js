const colors = {
  main: '#A1AF69',
  text: '#41423F',
};

export default {colors};
