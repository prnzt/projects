export const dummyData =
        [{
                title: 'Video Consultation', url: 'https://i.ibb.co/Np3rL1H/doctor-consultation.jpg',
                description: "The safest Consultation.",
                id: 1

        },
        {
                title: 'Book An Appointment', url: 'https://i.ibb.co/3F8T79P/1548142945-Sprals-Offers-Book-Doctors-Appointment-Online-Blog.jpg',
                description: "Online Appointment.",
                id: 2
        },
        {
                title: 'Order Medicines', url: 'https://i.ibb.co/TwDn97N/Buy-Medicines-Online.jpg',
                description: "Free Home Delivery.",
                id: 3
        }]

        export const dummyData2 =
        [{
                url: 'https://i.ibb.co/QX7Z2Mt/download.jpg',
              

        },
        {
                 url: 'https://i.ibb.co/zQwXKmX/best-hospital-kolkata.png',
                
        },
        {
                 url: 'https://i.ibb.co/gdrRwgH/Hospital-building-medical-icon-Healthcare-hospital-and-medical-diagnostics-Urgency-and-emergency-ser.jpg',
               
        }]